const Knex = require("knex");

exports.seed = async function seed(knex){
    await knex("clientes").insert([
        { nome: "Fanora", email: "fanora@camerapriva.gov.br", telefone: 3199114578, endereco: "De baixo de qualquer ponte" }
    ]).onConflict('id')
    .ignore();;
};
