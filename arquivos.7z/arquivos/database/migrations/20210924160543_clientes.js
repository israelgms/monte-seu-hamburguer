exports.up = function (knex) {
    return knex.schema.createTable('clientes', (table) => {
        table.increments('id');
        table.string('nome', 100).notNullable();
        table.string('email', 100).notNullable();
        table.integer('telefone', 12).notNullable();
        table.string('endereco', 100).notNullable().defaultTo('Solicitado');
        table.timestamps(true,true);
    });
};

exports.down = function (knex) {
    return knex.schema.dropTable('clientes');
};

